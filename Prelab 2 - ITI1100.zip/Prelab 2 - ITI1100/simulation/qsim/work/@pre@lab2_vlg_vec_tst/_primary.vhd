library verilog;
use verilog.vl_types.all;
entity PreLab2_vlg_vec_tst is
end PreLab2_vlg_vec_tst;
