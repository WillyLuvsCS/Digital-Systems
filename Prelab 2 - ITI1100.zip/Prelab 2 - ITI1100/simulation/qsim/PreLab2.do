onerror {quit -f}
vlib work
vlog -work work PreLab2.vo
vlog -work work PreLab2.vt
vsim -novopt -c -t 1ps -L cycloneive_ver -L altera_ver -L altera_mf_ver -L 220model_ver -L sgate work.PreLab2_vlg_vec_tst
vcd file -direction PreLab2.msim.vcd
vcd add -internal PreLab2_vlg_vec_tst/*
vcd add -internal PreLab2_vlg_vec_tst/i1/*
add wave /*
run -all
